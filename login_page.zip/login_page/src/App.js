import React from 'react';
import './App.css';
import  Login from './Login/Login.js';
import './Login/Login.css';
import'bootstrap/dist/css/bootstrap.css';


function App() {
  return (
    <div>
    
    <Login>
      
   </Login>

    </div>
  );
}

export default App;
