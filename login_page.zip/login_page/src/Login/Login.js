import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faKey } from '@fortawesome/free-solid-svg-icons';


class Auth extends Component {

	
   handleSubmit(event){
   //event.preventDefault();
   const data=new FormData(event.target);
   console.log(data.get('email'));
   console.log(data.get('password'));
	}

	render() {
		return (
			<div className="container-contact100">
				<div className="wrap-contact100">
					<form className="contact100-form validate-form" onSubmit={this.handleSubmit}>
						<span className="contact100-form-title">
							Log-in to your account
				<hr className="change"></hr>
						</span>

						<label className="label-input100" for="first-name" ><FontAwesomeIcon icon={faUser} /><b> &nbsp;&nbsp;Enter your Username</b></label>

						<div className="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">

							<input id="email" class="input100" type="email" name="email" placeholder="Log-in"></input>
							<span className="focus-input100"></span>
						</div>
						<label className="label-input100" for="email"><FontAwesomeIcon icon={faKey} /><b> &nbsp;&nbsp;Enter your password</b></label>
						<div className="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
							<input id="password" class="input100" type="password" name="password" placeholder="Password"></input>
							<span className="focus-input100"></span>
						</div>
						<div className="container-contact100-form-btn">
							<button className="contact100-form-btn" type="submit">
								Login
					</button>
						</div>
					</form>
				</div>
			</div>
		)

	}
};


export default Auth;
